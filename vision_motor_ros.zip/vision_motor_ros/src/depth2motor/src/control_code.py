#simple PWM control
#Using switch and depth info to control motor
from __future__ import division
import time
import Adafruit_PCA9685
import RPi.GPIO as GPIO

import rospy
from std_msgs.msg import String, Header, Int16
import numpy as np

import matplotlib.pyplot as plt
import math
from geometry_msgs.msg import Polygon, Point32, Vector3, Pose
from nav_msgs.msg import Odometry

switch_add =         #TBD switch gpio pin
#initialize the GPIO pins
GPIO.setmode(GPIO.BOARD)
GPIO.setup(switch_add,GPIO.IN)

#initialize the pwm channel
pwm = Adafruit_PCA9685.PCA9685()
pwm.set_pwm_freq(60)

class Control:
  def __init__(self):
    self.sub =rospy.Subscriber("/depth_infor", Float32MultiArray, self.getInfor, queue_size=1)

  def getInfor(self,msg):
    self.depth = msg.data
    self.depth2pwm(self.depth)

  def depth2pwm(depth_list):
    #transfer the depth info to pwm signal
    max_dep =100        #TBD
    min_dep =0        #TBD
    max_pwm =4096       #TBD
    min_pwm =0        #TBD
    pwm_signal = []
    def trans(depth):
        return (depth-min_dep)/(max_dep-min_dep)*(max_pwm-min_pwm) + min_pwm
    for i in range(len(depth_list)):
       signal = trans(depth_list[i])
       pwm.set_pwm(i,0,signal)


#main loop


if __name__=="__main__":
    rospy.init_node("control_code")
    Control()
    
